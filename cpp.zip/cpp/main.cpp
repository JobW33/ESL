#include <error.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdbool.h>

#include <signal.h>
#include <stdio.h>

#include "soc_system.h"
#include "hardware_manager.h"

void sigint(int a)
{
	//reset
	hardware_manager justReset = hardware_manager();
	printf("Existing program, triggering software reset\n");
    exit(-1);
}


int main(int argc, char** argv) {

  // set the signal interrupt
  signal(SIGINT, sigint);

  // time to wait between each loop
  int delay = 1000000; //us
  
  // create the hardware manager
  hardware_manager controller = hardware_manager();

  // set the duty cycle limits
  float pitchLimit = 0.8;
  controller.pitchController->setDutyCycleLimit(pitchLimit);

  float yawLimit = 0.8;
  controller.yawController->setDutyCycleLimit(yawLimit);


  int index = 0;
  float fraction = 0.0;
  bool direction = false;

  while (true)
  {
    // set the new duty cycle
    controller.pitchController->setDutyCycle(fraction);
    controller.yawController->setDutyCycle(fraction);

    // reverse the directions
    controller.pitchController->setDir(direction);
    controller.yawController->setDir(direction);

    // update the next duty cycle and reverse the next direction
    fraction = fraction >= 0.99 ? 0.0 : fraction + 0.01;
    direction = !direction;


    //get pitch and yaw
    int pitch = controller.pitchDecoder->getCount();
    int yaw   = controller.yawDecoder->getCount();
    
    //print status update
    printf("%4d  pitch: %8d yaw: %8d percentage: %3f\n", index, yaw, pitch, fraction);
	
    // sleep and update index
    usleep(delay);
    index = index + 1;
  }

  return 0;
}
