#include <error.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdbool.h>

#include "soc_system.h"

#include <signal.h>
#include <stdio.h>

class PWM_controller{
public:
  int reg;
  float limiter = 1.0;

  PWM_controller(int &mapping){
    reg = mapping;
  }

  /**
   * Limits the maximum duty cycle this controller can set
  */
  void setDutyCycleLimit(float limit){
    if (limit < 0.0 or limit > 1.0){
      return;
    }

    limiter = limit;
  }

  /**
   * Sets the direction of this controller. True for forward, False for backwards
  */
  void setDir(bool forward){
    // mask bit [30]
    reg = reg & 0xBFFFFFFF | ((forward ? 1 : 0) << 30);
  }

  /**
   * Sets the duty cycle. Accepts any value between 0.0 and 1.0
   * If the value is above the limiter value, it simply sets the value to the limiter
  */
  void setDutyCycle(float fraction){
    // just return if the value is invalid
    if (fraction < 0.0 or fraction > 1.0){
      return;
    }
    // if the duty cycle exceeds the limitor, set it to the max allowed value
    fraction = (fraction > limiter? limiter : fraction);

    // 11bits for the duty cycle, 2^11=2048
    uint32_t max_duty_val = 2047;

    // calculate the correct duty cycle value
    uint32_t duty_val = uint32_t(fraction * max_duty_val);

    //mask with 11 bits just to be sure
    duty_val = duty_val & 0x000007FF;  

    // Set the lower 11 bits to zero and bitwise or the new duty cycle
    reg = (reg & 0xFFFFF800) | duty_val;

  }
  
  /**
   * Software reset for this controller (includes all previously set values)
  */
  void reset(){
    reg = 1 << 31;
    reg = 0;
  }
};


class quadrature_decoder{
public:
  int reg;
  int rst;

  quadrature_decoder(int &mapping, int &reset){
    reg = mapping;
    rst = reset;
  }

  /**
   * Get the count value of this decoder. This value stretches the entire 32 bit register
  */
  int getCount(){
    return reg;
  }

    /**
   * Software reset, shared by BOTH decoders. 
  */
  void reset(){
    reg = 1 << 31;
    reg = 0;
  }
};

class hardware_manager {

  // QUADRATURE DECODER REGISTERS/WIRES
	//  esl_map[0] QD qd_control					[31]=software_reset
	//  esl_map[1] QD pitch_out					[DATA_WIDTH:0]=counter_output
	//  esl_map[2] QD yaw_out						[DATA_WIDTH:0]=counter_output
  
  // STEERING REGISTERS/WIRES
	//  esl_map[3] Steering pitch_control   		[31]=software_reset, [30]=dir, [COUNT_SIZE:0]=duty_cycle
	//  esl_map[4] Steering yaw_control 			[31]=software_reset, [30]=dir, [COUNT_SIZE:0]=duty_cycle

private:
  int fd = 0;
  int* esl_map = NULL;

public:
  quadrature_decoder *yawDecoder;
  quadrature_decoder *pitchDecoder;
  PWM_controller *yawController;
  PWM_controller *pitchController;

  hardware_manager(){
    initMapping();
    softwareReset();

    this->pitchDecoder = new quadrature_decoder(esl_map[1], esl_map[0]);
    this->yawDecoder = new quadrature_decoder(esl_map[2], esl_map[0]);
    this->pitchController = new PWM_controller(esl_map[3]);
    this->yawController = new PWM_controller(esl_map[4]);
  }

  /**
   * initialise the memory mapping 
  */
  void initMapping(){
    fd = open("/dev/mem", O_RDWR | O_SYNC);

    if (fd < 0) {
      perror("Couldn't open /dev/mem\n");
      exit(-1);
    }

    esl_map = (int*)mmap(NULL, HPS_0_ARM_A9_0_ESL_BUS_DEMO_0_SPAN, PROT_READ | PROT_WRITE, MAP_SHARED, fd, HPS_0_ARM_A9_0_ESL_BUS_DEMO_0_BASE);
    if (esl_map == MAP_FAILED) {
      perror("Couldn't map bridge.");
      close(fd);
      exit(-1);
    }
  }

  /**
   * Perform a full software reset
  */
  void softwareReset(){
    //reset
    esl_map[0] = 1 << 31;
    esl_map[0] = 0;
    esl_map[3] = 1 << 31;
    esl_map[3] = 0;
    esl_map[4] = 1 << 31;
    esl_map[4] = 0;
  }
};
