
When the RPI is used, compile with: hardware/spidev/spidev_lib.c

When the controller is used, compile with: controller/tilt/PositionControllerTilt.cpp controller/tilt/common/xxinteg.cpp controller/pan/PositionControllerPan.cpp